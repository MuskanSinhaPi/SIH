import React from 'react'
import Image from 'next/image'

export default function Page() {
  return (
    <div>
      Hello Idk what to do here empty space
    </div>
    // <Image src="https://cdn.dribbble.com/users/1998175/screenshots/9963575/media/afc56bd6a8a467ec05682788371ad897.png" alt="Picture of the author" width={1500} height={1500} />
  )
}
